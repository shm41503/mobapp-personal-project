package edu.skku.map.myapplication

data class Drink(
    val name: String,
    val imageUrl: String,
    val description: String,
    val rating: Double
)
